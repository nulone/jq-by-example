"""
Security utilities for safe logging and data handling.

This module provides utilities to prevent sensitive data exposure in logs
and ensure safe handling of user-provided data.
"""


def truncate_for_log(data: str, max_length: int = 100) -> str:
    """
    Truncate data for safe logging without exposing large payloads.

    Args:
        data: The string data to truncate.
        max_length: Maximum length before truncation. Defaults to 100.

    Returns:
        Truncated string with ellipsis if truncated.
    """
    if len(data) <= max_length:
        return data

    return data[:max_length] + "..."


def sanitize_for_log(data: dict, sensitive_keys: list[str]) -> dict:
    """
    Remove sensitive keys from dict for safe logging.

    Args:
        data: Dictionary that may contain sensitive data.
        sensitive_keys: List of keys to redact (case-insensitive).

    Returns:
        Dictionary with sensitive values replaced with "[REDACTED]".
    """
    sanitized = data.copy()
    sensitive_keys_lower = [k.lower() for k in sensitive_keys]

    for key in list(sanitized.keys()):
        if key.lower() in sensitive_keys_lower:
            sanitized[key] = "[REDACTED]"

    return sanitized
